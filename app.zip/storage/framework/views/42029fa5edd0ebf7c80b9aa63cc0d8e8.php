<!DOCTYPE html>
<html>

<head>
    <title>R17 Group</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>


</head>

<body class="font-lato">

    <div class="bg-slate-100 w-full h-screen flex flex-row justify-center items-center
    py-12">
        <div class="w-4/6 h-full bg-white rounded-xl p-10 shadow-2xl">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
    <?php echo $__env->make('persons.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('persons.modalImport', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\portofolio\r17-app\resources\views/persons/layout.blade.php ENDPATH**/ ?>